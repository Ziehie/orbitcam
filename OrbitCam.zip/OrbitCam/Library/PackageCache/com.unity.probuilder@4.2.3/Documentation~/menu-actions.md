﻿# Actions

Use this sub-menu to access editor and component windows.

![Tools > ProBuilder > Actions menu](images/menu-actions.png)

## Strip All ProBuilder Scripts in Scene

Removes all ProBuilder scripts from all GameObjects in this Scene, and only leaves the Models.

## Strip ProBuilder Scripts in Selection

Removes all ProBuilder scripts from selected GameObjects, and only leaves the Models.
